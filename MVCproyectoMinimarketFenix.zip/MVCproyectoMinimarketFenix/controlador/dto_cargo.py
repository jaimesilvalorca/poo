from modelo.cargo import Cargo
from dao.dao_cargo import daoCargo

class CargoDTO:
    pass
